import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Login extends PathPages{
	private static String page="login.html";
	private static String heading="Hotel Booking Application";

	public Login() {
		super(page, heading);
		PageFactory.initElements(browser.driver, this);
	}

	@FindBy(how=How.NAME,name="userName")
	private WebElement userName;
	
	@FindBy(how=How.NAME,name="userPwd")
	private WebElement password;

	public String getUserName() {
		return userName.getText();
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public String getPassword() {
		return password.getText();
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	
	@FindBy(how=How.CLASS_NAME,className="btn")
	private WebElement button;
	public void submitApplication()
	{
		button.click();
	}

	@FindBy(how=How.ID,id="userErrMsg")
	private WebElement userErrMsg;
	public boolean invalidUserName() {
		// TODO Auto-generated method stub
		System.out.println("\n"+userErrMsg.getText());
		if((userErrMsg.getText()).equals("* Please enter userName."))
			return true;
		return false;
	}

	@FindBy(how=How.ID,id="pwdErrMsg")
	private WebElement pwdErrMsg;
	public boolean invalidPasswordName() {
		if((pwdErrMsg.getText()).equals("* Please enter password."))
			return true;
		return false;
	}

	public boolean successfulLogin() {
		// TODO Auto-generated method stub
		heading="Hotel Booking";
		if(browser.title().equals("Hotel Booking"))
			return true;
		return false;
	}

	public boolean invalidLogin() {
		// TODO Auto-generated method stub
		Alert alert=browser.driver.switchTo().alert();
		String alertMsg=alert.getText();
		alert.accept();
		if(alertMsg.equals("Invalid login! Please try again!"))
			return true;
		return false;
	}
}