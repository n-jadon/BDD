import org.junit.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefHotelBooking {

	private HotelBooking page=new HotelBooking();
	
	@Given("^I am on the Hotel booking application$")
	public void i_am_on_the_Hotel_booking_application() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.goTo();
	}

	@Given("^I enter (.*) as first name$")
	public void i_enter_nJ_as_first_name(String firstName) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setFirstName(firstName);
	}

	@Given("^I enter (.*) as Last name$")
	public void i_enter_singh_as_Last_name(String lastName) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setLastName(lastName);
	}

	@Given("^I enter (.*) a Email$")
	public void i_enter_ram_gmail_com_a_Email(String email) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setEmail(email);
	}

	@Given("^I enter (.*) as mobile$")
	public void i_enter_as_mobile(String mobileNo) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setMobileNo(mobileNo);
	}

	@Given("^I enter (.*) as address$")
	public void i_enter_Talwade_as_address(String address) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setAddress(address);
	}

	@Given("^I select (.*) as city$")
	public void i_select_Pune_as_city(String city) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setCity(city);
	}

	@Given("^I select (.*) as state$")
	public void i_select_Maharashtra_as_state(String state) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setState(state);
	}

	@Given("^I select (\\d+) as number of guest staying$")
	public void i_select_as_number_of_guest_staying(int persons) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setPersons(persons+"");
	}

	@Given("^I enter (.*) as card holder name$")
	public void i_enter_ram_as_card_holder_name(String cardHolderName) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setCardHolderName(cardHolderName);
	}

	@Given("^I enter (\\d+) as debit card number$")
	public void i_enter_as_debit_card_number(int debitCardNumber) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setDebitCardNumber(debitCardNumber+"");
	}

	@Given("^I enter (\\d+) as cvv$")
	public void i_enter_as_cvv(int cvv) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setCvv(cvv+"");
	}

	@Given("^I enter (\\d+) as Expiration month$")
	public void i_enter_as_Expiration_month(int expMonth) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setExpMonth(expMonth+"");
	}

	@Given("^I enter (\\d+) as Expiration year$")
	public void i_enter_as_Expiration_year(int expYear) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.setExpYear(expYear+"");
	}

	@When("^I confirm Booking$")
	public void i_confirm_Booking() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    page.getBtn().click();
	}

	@Then("^I should see the application complete confirmation$")
	public void i_should_see_the_application_complete_confirmation() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}
	@After
	public void tearDown(){
		
		page.getBrowser().close();
	}
}
