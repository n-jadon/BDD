import org.junit.Assert;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefs {
	
	private Login page=new Login();
	
	@Given("^I am on the login screen$")
	public void i_am_on_the_login_screen() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.goTo();
		Assert.assertTrue(page.isAt());
	}

	@When("^I click on login$")
	public void i_click_on_login() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		page.submitApplication();
	}

	@Then("^please enter userName message shows$")
	public void please_enter_userName_message_shows() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		Assert.assertTrue(page.invalidUserName());
	}

	@Then("^please enter password message shows$")
	public void please_enter_password_message_shows() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		Assert.assertTrue(page.invalidPasswordName());
	}

	@Then("^successful login to hotel booking page$")
	public void successful_login_to_hotel_booking_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
		Assert.assertTrue(page.successfulLogin());
	}
	
	@Given("^i write (.*) as userName$")
	public void i_write_as_userName(String userName) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setUserName(userName);
	}

	@Given("^i write (.*) as userPassword$")
	public void i_write_as_userPassword(String password) throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setPassword(password);
	}

	@Then("^alert of invalid display shows$")
	public void alert_of_invalid_display_shows() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		Assert.assertTrue(page.invalidLogin());
	}
	
	@After
	public void tearDown(){
		
		page.getBrowser().close();
	}
}
