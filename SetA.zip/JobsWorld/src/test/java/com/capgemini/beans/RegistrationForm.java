package com.capgemini.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.pom.Browser;
import com.capgemini.pom.PathPages;


public class RegistrationForm extends PathPages{
	
	private static String page = "RegistrationForm.html";
	private static String title = "Welcome to JobsWorld";
	public RegistrationForm(Browser browser) {
		super(page, title, browser);
		PageFactory.initElements(super.getBrowser().driver, this);
	}
	
	@FindBy(how = How.NAME, using = "userid")
	@CacheLookup
	private WebElement userId;
	
	@FindBy(how = How.NAME, using = "passid")
	@CacheLookup
	private WebElement password;
	
	@FindBy(how = How.NAME, using = "username")
	@CacheLookup
	private WebElement name;
	
	@FindBy(how = How.NAME, using = "address")
	@CacheLookup
	private WebElement address;
	
	@FindBy(how = How.NAME, using = "country")
	@CacheLookup
	private WebElement country;
	
	@FindBy(how = How.NAME, using = "zip")
	@CacheLookup
	private WebElement zipCode;
	
	@FindBy(how = How.NAME, using = "email")
	@CacheLookup
	private WebElement email;
	
	@FindBy(how = How.NAME, using = "sex")
	@CacheLookup
	private WebElement sex;
	
	@FindBy(how = How.NAME, using = "en")
	@CacheLookup
	private WebElement languageEn;
	
	@FindBy(how = How.NAME, using = "nonen")
	@CacheLookup
	private WebElement languageNonEn;
	
	@FindBy(how = How.NAME, using = "desc")
	@CacheLookup
	private WebElement about;
	
	@FindBy(how = How.NAME, using = "submit")
	@CacheLookup
	private WebElement submitBtn;
	
	public String getUserId() {
		return userId.getText();
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public String getPassword() {
		return password.getText();
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public String getName() {
		return name.getText();
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public String getAddress() {
		return address.getText();
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCountry() {
		return country.getText();
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public String getZipCode() {
		return zipCode.getText();
	}

	public void setZipCode(String zipCode) {
		this.zipCode.sendKeys(zipCode);
	}

	public String getEmail() {
		return email.getText();
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getSex() {
		return sex.getText();
	}

	@FindBy(xpath="/html/body/form/ul/li[16]/input")
	private WebElement male;
	
	@FindBy(xpath="/html/body/form/ul/li[17]/input")
	private WebElement female;
	public void setSex(String sex) {
		if(sex.equals("Male"))
			male.click();
		else if(sex.equals("Female"))
			female.click();
	}

	public String getLanguageEn() {
		return languageEn.getText();
	}

	public void setLanguageEn() {
		this.languageEn.click();;
	}

	public String getLanguageNonEn() {
		return languageNonEn.getText();
	}

	public void setLanguageNonEn() {
		this.languageNonEn.click();;
	}

	public String getAbout() {
		return about.getText();
	}

	public void setAbout(String about) {
		this.about.sendKeys(about);
	}
	public void setSubmitBtn() {
		this.submitBtn.click();;
	}	
}
