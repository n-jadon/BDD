package com.capgemini.jobsWorld;

import org.junit.Assert;
import org.openqa.selenium.Alert;

import com.capgemini.beans.RegistrationForm;
import com.capgemini.pom.Browser;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefsRegistrationForm {
	
	private RegistrationForm page;
	private Browser browser;
	
	@Before
	public void setup() {
		browser=new Browser();
		page=new RegistrationForm(browser);
	}

	@Given("^I am on registration page$")
	public void i_am_on_registration_page() throws Throwable {
		page.goTo();
		Assert.assertTrue(page.isAt());
	}

	@Given("^I entered valid (.*) userId$")
	public void i_entered_valid_nitinjad_userId(String userId) throws Throwable {
	    page.setUserId(userId);
	}

	@Given("^I entered valid (.*) password$")
	public void i_entered_valid_njadonit_password(String password) throws Throwable {
		page.setPassword(password);
	}

	@Given("^I entered valid (.*) name$")
	public void i_entered_valid_Nitin_name(String name) throws Throwable {
		page.setName(name);
	}

	@Given("^I entered valid (.*) address$")
	public void i_entered_valid_mathura_address(String address) throws Throwable {
		page.setAddress(address);
	}

	@Given("^I select (.*) country$")
	public void i_select_India_country(String country) throws Throwable {
		page.setCountry(country);
	}

	@Given("^I entered valid (.*) zipcode$")
	public void i_entered_valid_zipcode(String zipCode) throws Throwable {
		page.setZipCode(zipCode);
	}

	@Given("^I entered valid (.*) emailId$")
	public void i_entered_valid_njitin_gmail_com_emailId(String email) throws Throwable {
		page.setEmail(email);
	}

	@Given("^I select (.*) as sex$")
	public void i_select_male_as_sex(String sex) throws Throwable {
		page.setSex(sex);
	}
	@Given("^I select English as language$")
	public void i_select_English_as_language() throws Throwable {
		page.setLanguageEn();
	}

	@Given("^I select nonEnglish as language$")
	public void i_select_nonEnglish_as_language() throws Throwable {
		page.setLanguageNonEn();
	}

	@When("^I submit form$")
	public void i_submit_form() throws Throwable {
		page.setSubmitBtn();
	}

	@Then("^confirm alertbox display$")
	public void confirm_alertbox_display() throws Throwable {
		Alert alert=page.getBrowser().driver.switchTo().alert();
		String alertMsg=alert.getText();
		alert.accept();
		if(alertMsg.equals("Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile"))
			Assert.assertTrue(true);
		else
			Assert.assertTrue(false);
	}
	
	@Given("^I entered invalid (.*) userId$")
	public void i_entered_invalid_nj_userId(String userId) throws Throwable {
		page.setUserId(userId);
	}

	@Given("^I entered invalid (.*) password$")
	public void i_entered_invalid_it_password(String password) throws Throwable {
		page.setPassword(password);
	}

	@Given("^I entered invalid (.*) name$")
	public void i_entered_invalid_idn_name(String name) throws Throwable {
		page.setName(name);
	}

	@Given("^I entered invalid (.*) address$")
	public void i_entered_invalid_address(String address) throws Throwable {
		page.setAddress(address);
	}

	@Given("^I entered invalid (.*) zipcode$")
	public void i_entered_invalid_a_zipcode(String zipCode) throws Throwable {
		page.setZipCode(zipCode);
	}

	@Given("^I entered invalid (.*) emailId$")
	public void i_entered_invalid_njitin_com_emailId(String email) throws Throwable {
		page.setEmail(email);
	}
	
	@Then("^invalid username alertbox display$")
	public void invalid_username_alertbox_display() throws Throwable {
		Alert alert=page.getBrowser().driver.switchTo().alert();
		String alertMsg=alert.getText();
		alert.accept();
		if(alertMsg.equals("User Id should not be empty / length be between 5 to 12"))
			Assert.assertTrue(true);
		else
			Assert.assertTrue(false);
	}
	
	@Then("^invalid password alertbox display$")
	public void invalid_password_alertbox_display() throws Throwable {
		Alert alert=page.getBrowser().driver.switchTo().alert();
		String alertMsg=alert.getText();
		alert.accept();
		if(alertMsg.equals("Password should not be empty / length be between 7 to 12"))
			Assert.assertTrue(true);
		else
			Assert.assertTrue(false);
	}
	
	@Then("^invalid name alertbox display$")
	public void invalid_name_alertbox_display() throws Throwable {
		Alert alert=page.getBrowser().driver.switchTo().alert();
		String alertMsg=alert.getText();
		alert.accept();
		System.out.println(alertMsg);
		if(alertMsg.equals("Name should not be empty and must have alphabet characters only"))
			Assert.assertTrue(true);
		else
			Assert.assertTrue(false);
	}

@Then("^invalid address alertbox display$")
public void invalid_address_alertbox_display() throws Throwable {
	Alert alert=page.getBrowser().driver.switchTo().alert();
	String alertMsg=alert.getText();
	alert.accept();
	if(alertMsg.equals("User address must have alphanumeric characters only"))
		Assert.assertTrue(true);
	else
		Assert.assertTrue(false);
}

@Then("^invalid zipCode alertbox display$")
public void invalid_zipCode_alertbox_display() throws Throwable {
	Alert alert=page.getBrowser().driver.switchTo().alert();
	String alertMsg=alert.getText();
	alert.accept();
	if(alertMsg.equals("ZIP code must have numeric characters only"))
		Assert.assertTrue(true);
	else
		Assert.assertTrue(false);
}

@Then("^invalid email alertbox display$")
public void invalid_email_alertbox_display() throws Throwable {
	Alert alert=page.getBrowser().driver.switchTo().alert();
	String alertMsg=alert.getText();
	alert.accept();
	if(alertMsg.equals("You have entered an invalid email address!"))
		Assert.assertTrue(true);
	else
		Assert.assertTrue(false);
}

@Then("^Select sex alertbox display$")
public void select_sex_alertbox_display() throws Throwable {
	Alert alert=page.getBrowser().driver.switchTo().alert();
	String alertMsg=alert.getText();
	alert.accept();
	if(alertMsg.equals("Please Select gender"))
		Assert.assertTrue(true);
	else
		Assert.assertTrue(false);
}

	
	@After
	public void close() {
		if(page.getBrowser()!=null)
		page.getBrowser().close();
	}

}
