package com.capgemini.pom;
public class PathPages {

	private String url;
	private String title; 
	private Browser browser;
	public PathPages(String url,String title, Browser browser) {
	String webPageLocation="file:///"+System.getProperty("user.dir")+"/src/main/webapp/";
	this.url=webPageLocation+url;
	this.title=title;
	this.browser=browser;
	}
	
	public void goTo() {
		
		browser.goTo(url);
	}

	public boolean isAt() {
		return browser.title().equals(title);
	}
	
	public Browser getBrowser()
	{
		return this.browser;
	}

	
	
}
